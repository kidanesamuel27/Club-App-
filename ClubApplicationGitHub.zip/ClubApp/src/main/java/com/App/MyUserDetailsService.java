package com.App;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.App.model.User;
import com.App.repository.UserRepository;

@Service
public class MyUserDetailsService implements UserDetailsService {
	@Autowired
	private UserRepository repo;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		User user = repo.findByUsername(username);
		if (user == null)
			throw new UsernameNotFoundException("USer 404");

		return new UserPrincipal(user);
	}

}

//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.stereotype.Service;
//@Service
//public class MyUserDetailsService implements UserDetailsService {
//	@Autowired
//	private ClubRepository repo;
//
//	@Override
//	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//		// TODO Auto-generated method stub
//		System.out.println("In the MyUserDetailsService");
//		Club user = repo.findAll();
//				//findByUsername(username);
//		if (user == null)
//			throw new UsernameNotFoundException("USer 404");
//
//		return new UserPrincipal(user);
//	}
//
//
//}
