package com.App.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.App.model.Club;
import com.App.model.User;
import com.App.repository.ClubRepository;
import com.App.service.ClubService;
import com.App.service.UserService;

@Controller
public class ClubController {
	@Autowired
	ClubRepository repo;
	@Autowired
	ClubService serve;
	@Autowired
	UserService serv;

	@RequestMapping("/")
	public String home() {
		System.out.println("IN CONTROLLER");
		return "login.jsp";
	}
	
	
	@RequestMapping("/registerUser") // coming from home.jsp
	public String addMember(Model model, @RequestParam(value = "id") Long memId,
			@RequestParam(value = "username") String memUN, @RequestParam(value = "password") String memPd,
			@RequestParam(value = "email") String memEmail, User user) {

		model.addAttribute("products", serv.addMemberService(memId, memUN, memPd, memEmail));
		return "home.jsp";
	}

	@RequestMapping("/showhome") // coming from home.jsp
	public String addMember(Model model, @RequestParam(value = "memId") Long memId,
			@RequestParam(value = "memName") String memName, @RequestParam(value = "memAddress") String memAddress,
			Club club) {

		model.addAttribute("products", serve.addMemberService(memId, memName, memAddress));
		return "home.jsp";
	}

	@RequestMapping("/getAlien")
	public String getMember(Model model) {
		System.out.println("In getAlien CONTROLLER ");
		// repo.deleteById((long) 2);
		model.addAttribute("products", serve.getMemberService());

		return "showMember.jsp";
	}

	@RequestMapping("/deleteID/{product.member_id}")
	public String deleteMember(Model model, Club club, @PathVariable("product.member_id") Long memId) {
		// model.addAttribute("products",repo.getOne(memId));
		club.setMember_id(memId);
		club.getMember_id();
		System.out.println("In Delete- Member CONTROLLER ");
		serve.deleteMemberService(memId);
		return "redirect:/getAlien";
	}

	@RequestMapping("/update/{product.member_id}")
	public String updateMember(Model model, Club club, @PathVariable("product.member_id") Long memId) {
		// model.addAttribute("products",repo.getOne(memId));
		club.setMember_id(memId);
		club.getMember_id();
		System.out.println("In update- Member CONTROLLER ");
		serve.updateMemberService(memId);
		return "redirect:/";
	}

}
