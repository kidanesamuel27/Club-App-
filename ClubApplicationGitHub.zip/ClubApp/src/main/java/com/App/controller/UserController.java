package com.App.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.App.model.User;
import com.App.service.UserService;

public class UserController {
	@Autowired
	UserService serve;

	@RequestMapping("/registerUser") // coming from home.jsp
	public String addMember(Model model, @RequestParam(value = "id") Long memId,
			@RequestParam(value = "username") String memUN, @RequestParam(value = "password") String memPd,
			@RequestParam(value = "email") String memEmail, User user) {

		model.addAttribute("products", serve.addMemberService(memId, memUN, memPd, memEmail));
		return "redirect:/";
	}

}
