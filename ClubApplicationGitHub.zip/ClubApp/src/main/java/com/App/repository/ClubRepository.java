package com.App.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.App.model.Club;

//import com.SecureApp.User;

@Repository
@Component


public interface ClubRepository extends JpaRepository<Club, Long> {

	//Club findByUsername(String username);
	

	

}
