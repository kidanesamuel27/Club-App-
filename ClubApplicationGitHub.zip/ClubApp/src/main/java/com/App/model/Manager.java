package com.App.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Manager {
	private int Managerid;
	private String ManagerName;
	private String ManagerAddress;
	
	@Id
	public int getManagerid() {
		return Managerid;
	}
	public void setManagerid(int managerid) {
		Managerid = managerid;
	}
	public String getManagerName() {
		return ManagerName;
	}
	public void setManagerName(String managerName) {
		ManagerName = managerName;
	}
	public String getManagerAddress() {
		return ManagerAddress;
	}
	public void setManagerAddress(String managerAddress) {
		ManagerAddress = managerAddress;
	}
	public Manager(int managerid, String managerName, String managerAddress) {
		super();
		Managerid = managerid;
		ManagerName = managerName;
		ManagerAddress = managerAddress;
	}
	
}
