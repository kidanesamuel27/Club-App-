package com.App.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class Club {

	@Override
	public String toString() {
		return "Club [member_id=" + member_id + ", member_name=" + member_name + ", member_address=" + member_address
				+ "]";
	}

	// @Id
	// @GeneratedValue(generator = "system-uuid")
//	@GenericGenerator(name = "system-uuid", strategy = "uuid")
//	@Column(name = "uuid", unique = true)
	@Id
	//@GeneratedValue(strategy = GenerationType.TABLE)

	private Long member_id;

	private String member_name;

	private String member_address;

	/**
	 * @return the member_id
	 */
	public Long getMember_id() {
		return member_id;
	}

	/**
	 * @param member_id the member_id to set
	 */
	public void setMember_id(Long member_id) {
		this.member_id = member_id;
	}

	/**
	 * @return the member_name
	 */
	public String getMember_name() {
		return member_name;
	}

	/**
	 * @param member_name the member_name to set
	 */
	public void setMember_name(String member_name) {
		this.member_name = member_name;
	}

	/**
	 * @return the member_address
	 */
	public String getMember_address() {
		return member_address;
	}

	/**
	 * @param member_address the member_address to set
	 */
	public void setMember_address(String member_address) {
		this.member_address = member_address;
	}

	public Club() {
	}

	public Club(Long member_id, String member_name, String member_address) {
		super();
		this.member_id = member_id;
		this.member_name = member_name;
		this.member_address = member_address;
	}
	

}