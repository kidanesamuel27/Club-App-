package com.App;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication

@ComponentScan({"com.model","com.controller","com.repository","com.App"})
@EnableAutoConfiguration
public class TestH2WebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestH2WebAppApplication.class, args);
		System.out.println("In Main run_Check now");
	}

}
