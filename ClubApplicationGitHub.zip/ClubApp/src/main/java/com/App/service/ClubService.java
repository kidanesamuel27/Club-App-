/**
 * 
 */
package com.App.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.App.model.Club;
import com.App.repository.ClubRepository;

/**
 * @author Samuel Kidane
 *
 */

@Service
public class ClubService {

	@Autowired
	ClubRepository repo;

	public Club addMemberService(@PathVariable Long memId, @PathVariable String memName,
			@PathVariable String memAddress) {
		Club club = new Club();
		club.setMember_id(memId);
		club.setMember_name(memName);
		club.setMember_address(memAddress);

		club.getMember_id();
		club.getMember_name();
		club.getMember_address();
		return repo.save(club);
	}

	public List<Club> listAll() {
		return repo.findAll();
	}

	public List<Club> getMemberService() {
		System.out.println("In getAlien CONTROLLER ");
		return repo.findAll();
	}

	public void deleteMemberService(@PathVariable Long mem) {
		System.out.println("IN Delete- Member CONTROLLER ");
		repo.deleteById(mem);
	}

	public void updateMemberService(@PathVariable Long mem) {
		System.out.println("IN update- Member CONTROLLER ");
		repo.findById(mem);
	}

}
