package com.App.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.App.model.User;
import com.App.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	UserRepository repo;



	public Object addMemberService(Long memId, String memUN, String memPd, String memEmail) {
		// TODO Auto-generated method stub
		User club = new User();
		club.setId(memId);
		club.setUsername(memUN);
		club.setPassword(memPd);
		club.setEmail(memEmail);
		
		
		club.getEmail();
		club.getPassword();

		return repo.save(club);
	}
		

}
