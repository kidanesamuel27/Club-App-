package com.App;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.App.controller.ClubController;
import com.App.repository.ClubRepository;
import com.App.service.ClubService;
import com.App.model.Club;
@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
class TestH2WebAppApplicationTests {
	@Autowired
	private ClubService serv;

	@InjectMocks
	ClubController appController;
	@Mock
	ClubRepository repository;
//		private Object mockMvc;
	private MockMvc mockMvc;

	private String memAddress;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(appController).build();
	}

//@Test
//	public void testShowLogin() throws Exception {
//		this.mockMvc.perform(get("/")).andExpect(status().isOk());
//	}
	@Test
	void contextLoads() {
	}

	@Test
	public void getMemberTest() {
		// Club clu = new Club((long) 1, "Samuel", "104 Turkey");
		// clubb.add(clu);
		when(repository.findAll()).thenReturn(serv.getMemberService());
		assertEquals(repository.findAll().size(), serv.getMemberService().size());
		// verify(serv.getMemberService().size());
	}

//	@Test
//	public void deleteMemberServiceTest() {
//	 Club clu = new Club();
//	clu.setMember_id((long) 1);
//	clu.setMember_name("Samuel");
//	clu.setMember_address("104 Turkey");
//	when(repository.deleteById(null)).thenReturn(serv.getMemberService());
//	assertEquals(repository.findAll().size(), serv.getMemberService().size());
//}

//	public void deleteMemberService(@PathVariable Long mem) {
//		System.out.println("IN Delete- Member CONTROLLER ");
//		repo.deleteById(mem);
//	}
//@Test
//public void testSaveProduct() {
//	Product product = new Product();
//	Product pro = new Product((long) 1, "Dog", "Yes", 1001);
//	when(repository.save(pro)).thenReturn(pro);
//	assertEquals(pro, repository.save(pro));
//}

}
