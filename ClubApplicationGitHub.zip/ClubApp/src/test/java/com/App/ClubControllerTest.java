package com.App;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.App.controller.ClubController;
import com.App.repository.ClubRepository;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class ClubControllerTest {
@InjectMocks
	ClubController appController;
@Mock
	ClubRepository repository;
//		private Object mockMvc;
	private MockMvc mockMvc;

@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(appController).build();
	}
@Test
	public void testShowLogin() throws Exception {
		this.mockMvc.perform(get("/")).andExpect(status().isOk());
	}
}
